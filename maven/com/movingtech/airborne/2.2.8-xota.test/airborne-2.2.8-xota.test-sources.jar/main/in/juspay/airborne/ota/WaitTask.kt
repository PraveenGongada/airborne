// Copyright 2025 Juspay Technologies
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package `in`.juspay.airborne.ota

import java.util.concurrent.Callable
import java.util.concurrent.FutureTask

internal class WaitTask : FutureTask<Unit>(Callable {}) {
    fun complete() {
        super.set(Unit)
    }

    override fun run() {} // 'run' is disabled for this task.
}
